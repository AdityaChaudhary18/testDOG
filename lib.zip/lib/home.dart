import 'package:flutter/material.dart';
import 'new_pet.dart';
import 'components/scroll_bar.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int selectedNum = 0;
  int selectedPage = 0;
  int selectedTab = 0;
  late PageController _pageController;

  List<String> images = ["Dog1", "Dog2", "Dog3", "Dog4", "+"];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.3);
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> pages = [
      Center(
        child: Column(
          children: [
            scrollableNumberBar(
              selected: selectedNum,
              fun: (x) {
                setState(() {
                  selectedNum = x;
                });
              },
            ),
          ],
        ),
      ),
      Center(
        child: Text(
          "Page 2",
          style: TextStyle(fontSize: 100, fontWeight: FontWeight.bold),
        ),
      ),
      Center(
        child: Text(
          "Page 3",
          style: TextStyle(fontSize: 100, fontWeight: FontWeight.bold),
        ),
      ),
      Center(
        child: Text(
          "Page 4",
          style: TextStyle(fontSize: 100, fontWeight: FontWeight.bold),
        ),
      ),
    ];
    final Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(children: [
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 80,
            width: size.width,
            child: Stack(
              children: [
                CustomPaint(
                  size: Size(size.width, 80),
                  painter: MyCustomPainter(),
                ),
                Center(
                  heightFactor: 0.6,
                  child: FloatingActionButton(
                    onPressed: () {
                      setState(() {
                        selectedPage = 2;
                      });
                    },
                    backgroundColor: Colors.pink,
                    child: Icon(
                      Icons.book,
                      color: Colors.white,
                    ),
                  ),
                ),
                Container(
                  width: size.width,
                  height: 80,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        onPressed: () {
                          setState(() {
                            selectedPage = 0;
                          });
                        },
                        icon: Icon(
                          Icons.home,
                          color: selectedPage == 0
                              ? Colors.pinkAccent
                              : Colors.white,
                          size: selectedPage == 0 ? 30 : 20,
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            selectedPage = 1;
                          });
                        },
                        icon: Icon(
                          Icons.pets,
                          color: selectedPage == 1
                              ? Colors.pinkAccent
                              : Colors.white,
                          size: selectedPage == 1 ? 30 : 20,
                        ),
                      ),
                      SizedBox(
                        width: 25,
                      ),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            selectedPage = 3;
                          });
                        },
                        icon: Icon(
                          Icons.chat_outlined,
                          color: selectedPage == 3
                              ? Colors.pinkAccent
                              : Colors.white,
                          size: selectedPage == 3 ? 30 : 20,
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            selectedPage = 4;
                          });
                        },
                        icon: Icon(
                          Icons.shop,
                          color: selectedPage == 4
                              ? Colors.pinkAccent
                              : Colors.white,
                          size: selectedPage == 4 ? 30 : 20,
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
        Column(
          children: [
            Stack(
              children: [
                Container(
                  height: 200,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage("images/appbarBackground.jpg")),
                  ),
                  child: Column(
                    children: [
                      SizedBox(
                        height: 25,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              SizedBox(
                                width: 20,
                              ),
                              Icon(Icons.menu),
                              SizedBox(
                                width: 20,
                              ),
                              Text(
                                "My Pets",
                                style: TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Icon(Icons.star_border),
                              Text(
                                "440",
                                style: TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                              SizedBox(
                                width: 20,
                              )
                            ],
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 50),
                  child: Container(
                    height: 200,
                    child: PageView.builder(
                        // padEnds: false,
                        itemCount: images.length,
                        physics: NeverScrollableScrollPhysics(),
                        onPageChanged: (x) {
                          if (x != images.length - 1) {
                            setState(() {
                              selectedTab = x;
                            });
                          } else {
                            print("Last Page");
                          }
                        },
                        controller: _pageController,
                        itemBuilder: (context, pagePosition) {
                          return FractionallySizedBox(
                            heightFactor:
                                selectedTab == pagePosition ? 1 : 0.35,
                            child: GestureDetector(
                              onTap: () {
                                if (pagePosition != images.length - 1) {
                                  setState(() {
                                    selectedTab = pagePosition;
                                  });
                                  _pageController.animateToPage(pagePosition,
                                      duration: Duration(milliseconds: 200),
                                      curve: Curves.linear);
                                } else {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => NewPet()));
                                }
                              },
                              child: CircleAvatar(
                                child: Text(images[pagePosition]),
                              ),
                            ),
                          );
                        }),
                  ),
                ),
              ],
            ),
            Container(
              height: 400,
              child: pages[selectedTab],
            )
          ],
        ),
      ]),
    );
  }
}

class MyCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = Colors.indigo
      ..style = PaintingStyle.fill;
    Path path = Path()..moveTo(0, 20);

    path.quadraticBezierTo(size.width * 0.2, 0, size.width * 0.5, 0);
    path.quadraticBezierTo(size.width * 0.8, 0, size.width, 20);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    // canvas.drawShadow(path, Colors.white, 5, true);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
